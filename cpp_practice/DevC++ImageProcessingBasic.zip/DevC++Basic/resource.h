//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinCImage.rc
//

#define MENU_READ                       40001
#define MENU_WRITE                      40002
#define MENU_PRINT                      40003
#define MENU_QUIT                       40004
#define MENU_HSV_GEN                    40006
#define MENU_CLEAR_IN                   40007
#define MENU_CLEAR_OUT                  40008
#define MENU_CLEAR_WORK                 40009
#define MENU_CLEAR_KEY                  40010

#define MENU_CLEAR                      40051
#define MENU_COPY                       40052
#define MENU_PASTE                      40053

#define MENU_COLORTO                    40020
#define MENU_GRAY                       40021
#define MENU_RED                        40022
#define MENU_GREEN                      40023
#define MENU_BLUE                       40024

#define MENU_MOSAIC                     40058
#define MENU_FILTERING                  40059
#define MENU_MINE                       40060
#define MENU_SAVE_RESULT                40061
#define MENU_SWAP                       40062

#define IDI_LENA                        13570

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40057
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
